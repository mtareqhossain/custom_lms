<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasMany};
class Section extends Model
{
    protected $fillable = ['course_id', 'title', 'position'];
    public function course(): BelongsTo { return $this->belongsTo(Course::class); }
    public function lessons(): HasMany { return $this->hasMany(Lesson::class)->orderBy('position'); }
}
