



<?php ($settings = \App\Models\SiteSetting::current()); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($settings->logo_path): ?>
    <img src="<?php echo e(asset('storage/'.$settings->logo_path)); ?>" alt="<?php echo e($settings->site_name); ?>" <?php echo e($attributes); ?> />
<?php else: ?>
    <span <?php echo e($attributes->merge(['class' => 'font-bold text-2xl tracking-tight text-gray-800'])); ?>>
        <?php echo e($settings->site_name); ?>

    </span>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/components/application-logo.blade.php ENDPATH**/ ?>