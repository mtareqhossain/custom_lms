<?php if (isset($component)) { $__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-layout','data' => ['title' => 'My courses']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My courses']); ?>
<div class="mx-auto max-w-4xl px-4 py-10">
    <h1 class="display text-3xl">My courses</h1>
    <div class="mt-6 space-y-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="panel flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
                <div class="flex-1">
                    <h2 class="display text-lg"><?php echo e($e->course->title); ?></h2>
                    <div class="mt-3 h-2 overflow-hidden rounded-full bg-[var(--line)]" role="progressbar"
                         aria-valuenow="<?php echo e($e->progress_percent); ?>" aria-valuemin="0" aria-valuemax="100">
                        <div class="h-full bg-[var(--teal)]" style="width: <?php echo e($e->progress_percent); ?>%"></div>
                    </div>
                    <p class="muted mt-2 text-sm">
                        <?php echo e($e->progress_percent); ?>% complete
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->expires_at): ?>
                            , <?php echo e($e->isActive() ? 'access ends '.$e->expires_at->diffForHumans() : 'access expired'); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </p>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->isActive()): ?>
                    <a href="<?php echo e(route('learn.show', $e->course)); ?>" class="btn"><?php echo e($e->progress_percent > 0 ? 'Continue' : 'Start'); ?></a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->certificate): ?><span class="pill">Certificate ready</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="panel p-8 text-center">
                <p class="font-medium">You have not started any courses yet.</p>
                <a href="<?php echo e(route('courses.index')); ?>" class="btn mt-4">Browse courses</a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3)): ?>
<?php $attributes = $__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3; ?>
<?php unset($__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3)): ?>
<?php $component = $__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3; ?>
<?php unset($__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/learn/my-courses.blade.php ENDPATH**/ ?>