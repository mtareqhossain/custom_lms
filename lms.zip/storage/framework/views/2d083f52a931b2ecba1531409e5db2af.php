<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['percent' => 0, 'size' => 56]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['percent' => 0, 'size' => 56]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $r = 20;
    $c = round(2 * M_PI * $r, 2);
    $offset = round($c * (1 - max(0, min(100, $percent)) / 100), 2);
?>
<div class="relative shrink-0" style="width: <?php echo e($size); ?>px; height: <?php echo e($size); ?>px" role="img" aria-label="<?php echo e($percent); ?>% complete">
    <svg viewBox="0 0 48 48" width="<?php echo e($size); ?>" height="<?php echo e($size); ?>" style="transform: rotate(-90deg)">
        <circle class="ring-bg" cx="24" cy="24" r="<?php echo e($r); ?>" fill="none" stroke-width="5"/>
        <circle class="ring-fg" cx="24" cy="24" r="<?php echo e($r); ?>" fill="none" stroke-width="5" stroke-linecap="round"
                stroke-dasharray="<?php echo e($c); ?>" stroke-dashoffset="<?php echo e($offset); ?>" style="--c: <?php echo e($c); ?>"/>
    </svg>
    <span class="absolute inset-0 grid place-items-center text-xs font-semibold"><?php echo e($percent); ?>%</span>
</div>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/components/ring.blade.php ENDPATH**/ ?>