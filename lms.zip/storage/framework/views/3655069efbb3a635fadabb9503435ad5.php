<?php if (isset($component)) { $__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-layout','data' => ['title' => 'Courses']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Courses']); ?>
<div class="mx-auto max-w-6xl px-4 py-10">
    <h1 class="display reveal text-3xl sm:text-4xl">Find a course</h1>

    <form method="GET" id="catalogue-form" class="reveal mt-6 flex flex-col gap-4">
        <input name="q" value="<?php echo e(request('q')); ?>" placeholder="Search by title or topic" class="field w-full" aria-label="Search courses">
        <div class="flex flex-wrap gap-2" role="group" aria-label="Filter by price">
            <?php ($pricing = request('pricing', '')); ?>
            <button type="submit" name="pricing" value="" class="chip <?php echo e($pricing === '' ? 'active' : ''); ?>">All prices</button>
            <button type="submit" name="pricing" value="free" class="chip <?php echo e($pricing === 'free' ? 'active' : ''); ?>">Free</button>
            <button type="submit" name="pricing" value="paid" class="chip <?php echo e($pricing === 'paid' ? 'active' : ''); ?>">Paid</button>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories->isNotEmpty()): ?>
            <div class="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
                <?php ($cat = request('category', '')); ?>
                <button type="submit" name="category" value="" class="chip <?php echo e($cat === '' ? 'active' : ''); ?>">All categories</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" name="category" value="<?php echo e($c->slug); ?>" class="chip <?php echo e($cat === $c->slug ? 'active' : ''); ?>"><?php echo e($c->name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </form>

    <div class="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('courses.show', $course)); ?>" class="course-card reveal" style="transition-delay: <?php echo e(($loop->index % 3) * 70); ?>ms">
                <div class="thumb-wrap relative aspect-video">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->thumbnail): ?>
                        <img src="<?php echo e(Storage::url($course->thumbnail)); ?>" alt="" class="h-full w-full object-cover">
                    <?php else: ?>
                        <div class="thumb-fallback aspect-video"><?php echo e(Str::of($course->title)->substr(0, 1)); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <span class="level-badge"><?php echo e(ucfirst($course->level)); ?></span>
                </div>
                <div class="p-5">
                    <h2 class="display text-lg leading-snug"><?php echo e($course->title); ?></h2>
                    <p class="muted mt-1 line-clamp-2 text-sm"><?php echo e($course->summary); ?></p>
                    <div class="mt-4 flex items-center justify-between text-sm">
                        <span class="muted"><?php echo e($course->lessons_count); ?> lessons</span>
                        <span class="pill"><?php echo e($course->isFree() ? 'Free' : $course->currency.' '.number_format($course->price_cents / 100, 2)); ?></span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="panel reveal col-span-full p-10 text-center">
                <p class="display text-xl">No courses match your search</p>
                <p class="muted mt-2">Try a different term, or clear your filters to see everything.</p>
                <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-quiet mt-5">Clear filters</a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <div class="mt-8"><?php echo e($courses->links()); ?></div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9)): ?>
<?php $attributes = $__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9; ?>
<?php unset($__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9)): ?>
<?php $component = $__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9; ?>
<?php unset($__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/catalog/index.blade.php ENDPATH**/ ?>