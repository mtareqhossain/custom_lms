<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['quiz', 'user']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['quiz', 'user']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $hasPassed = $quiz->hasPassed($user);
    $remaining = $quiz->attemptsRemaining($user);
?>

<div class="p-4 rounded-xl border flex items-center justify-between" style="border-color:#D5DCE1; background:#fff;">
    <div>
        <p class="font-medium flex items-center gap-2" style="color:#10222B;">
            <?php echo e($quiz->title); ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($quiz->is_required): ?>
                <span class="text-xs px-2 py-0.5 rounded-full" style="background:#F0B23A; color:#10222B;">Required</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </p>
        <p class="text-xs mt-1" style="color:#5B6B75;">
            Pass mark <?php echo e($quiz->pass_percentage); ?>%
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasPassed): ?>
                &middot; <span style="color:#085858;">Passed</span>
            <?php elseif($remaining === 0): ?>
                &middot; <span style="color:#991B1B;">No attempts remaining</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </p>
    </div>
    <a href="<?php echo e(route('quiz.show', $quiz)); ?>" class="px-3 py-1.5 rounded-lg text-sm font-medium text-white" style="background:#0B6E6E;">
        <?php echo e($hasPassed ? 'Review' : 'Take quiz'); ?>

    </a>
</div>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/components/quiz-card.blade.php ENDPATH**/ ?>