<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $user = auth()->user();
    $role = $user->hasRole('business') ? 'business' : ($user->hasAnyRole(['admin', 'instructor']) ? 'staff' : 'student');

    // [label, route name or /path, icon, optional extra route patterns for the active state]
    $groups = match ($role) {
        'business' => ['Organization' => [
            ['Overview', 'business.dashboard', 'grid', ['business.dashboard', 'business.course']],
            ['Team', 'business.students', 'users'],
            ['Certificates', 'business.certificates', 'award'],
            ['Import students', 'business.import.create', 'upload'],
        ]],
        'staff' => ['Teaching' => [
            ['Dashboard', 'instructor.dashboard', 'grid', ['instructor.*']],
            ['Studio', '/admin', 'pencil'],
        ]],
        default => ['Learning' => [
            ['Dashboard', 'student.dashboard', 'home'],
            ['My courses', 'my.courses', 'book'],
            ['Certificates', 'student.certificates', 'award'],
            ['Orders', 'orders.index', 'receipt'],
        ]],
    };
    $groups['Explore'] = [['Browse courses', 'courses.index', 'compass']];

    $initials = collect(explode(' ', trim($user->name)))->filter()->take(2)->map(fn ($p) => mb_strtoupper(mb_substr($p, 0, 1)))->implode('');
    $roleLabel = ['business' => 'Business admin', 'staff' => $user->hasRole('admin') ? 'Administrator' : 'Instructor', 'student' => 'Student'][$role];
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ? $title.' | ' : ''); ?><?php echo e(config('app.name')); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700&family=Public+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->make('partials.lms-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="antialiased" x-data="{ nav: false }" @keydown.escape.window="nav = false">
<div class="shell">
    <div class="scrim" x-show="nav" x-cloak @click="nav = false"></div>

    <aside class="sidebar" :class="{ 'open': nav }" aria-label="Main navigation">
        <div class="side-brand">
            <a href="<?php echo e(route('home')); ?>" class="display text-xl"><?php echo e(config('app.name')); ?></a>
        </div>
        <nav class="side-scroll">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="side-label"><?php echo e($label); ?></p>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $target = $item[1];
                        $isUrl = str_starts_with($target, '/');
                        $href = $isUrl ? url($target) : (Route::has($target) ? route($target) : null);
                        $patterns = $item[3] ?? [$target.'*'];
                        $active = ! $isUrl && request()->routeIs(...$patterns);
                    ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($href): ?>
                        <a href="<?php echo e($href); ?>" class="side-link <?php echo e($active ? 'active' : ''); ?>" <?php if($active): ?> aria-current="page" <?php endif; ?>>
                            <?php if (isset($component)) { $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-icon','data' => ['name' => $item[2]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item[2])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $attributes = $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $component = $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?> <?php echo e($item[0]); ?>

                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>
        <div class="side-user">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->avatarUrl()): ?>
                <img src="<?php echo e($user->avatarUrl()); ?>" alt="" class="avatar" style="object-fit:cover;">
            <?php else: ?>
                <span class="avatar"><?php echo e($initials); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="min-w-0 flex-1">
                <p class="truncate text-sm font-semibold"><?php echo e($user->name); ?></p>
                <p class="muted text-xs"><?php echo e($roleLabel); ?></p>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?>
                <button class="muted" title="Log out" aria-label="Log out"><?php if (isset($component)) { $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-icon','data' => ['name' => 'logout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $attributes = $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $component = $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?></button>
            </form>
        </div>
    </aside>

    <div class="content">
        <div class="topbar">
            <button type="button" class="menu-btn btn btn-quiet !px-3 !py-2" @click="nav = true" aria-label="Open menu"><?php if (isset($component)) { $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-icon','data' => ['name' => 'menu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $attributes = $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $component = $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?></button>
            <p class="display hidden text-lg lg:block"><?php echo e($title); ?></p>
            <div class="flex items-center gap-3 text-sm">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('profile.edit')): ?><a href="<?php echo e(route('profile.edit')); ?>" class="muted inline-flex items-center gap-1"><?php if (isset($component)) { $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-icon','data' => ['name' => 'user','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $attributes = $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $component = $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?> Profile</a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
            <div class="bg-[var(--mint)] px-4 py-3 text-center text-sm font-medium text-[var(--teal-dark)]" role="status"><?php echo e(session('status')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <main><?php echo e($slot); ?></main>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/components/panel-layout.blade.php ENDPATH**/ ?>