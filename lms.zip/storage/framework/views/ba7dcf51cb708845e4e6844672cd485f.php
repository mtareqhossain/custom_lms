<?php if (isset($component)) { $__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-layout','data' => ['title' => $course->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->title)]); ?>
<div class="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[1fr_22rem]">
    <div class="reveal">
        <div class="hero-thumb aspect-[21/9]">
            <?php ($intro = app(\App\Services\VideoUrlResolver::class)->resolveProvider($course->intro_video_provider, $course->intro_video_ref)); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($intro): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($intro['type'] === 'iframe'): ?>
                    <iframe src="<?php echo e($intro['url']); ?>" class="h-full w-full" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen title="Course intro"></iframe>
                <?php else: ?>
                    <video src="<?php echo e($intro['url']); ?>" class="h-full w-full object-cover" controls></video>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php elseif($course->thumbnail): ?>
                <img src="<?php echo e(Storage::url($course->thumbnail)); ?>" alt="" class="h-full w-full object-cover">
            <?php else: ?>
                <div class="thumb-fallback h-full w-full"><?php echo e(Str::of($course->title)->substr(0, 1)); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <span class="level-badge"><?php echo e(ucfirst($course->level)); ?></span>
        </div>

        <h1 class="display mt-6 text-3xl sm:text-4xl"><?php echo e($course->title); ?></h1>
        <p class="muted mt-3 max-w-2xl text-lg"><?php echo e($course->summary); ?></p>
        <div class="mt-3 flex items-center gap-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->instructor->avatarUrl()): ?>
                <img src="<?php echo e($course->instructor->avatarUrl()); ?>" alt="" class="h-7 w-7 rounded-full object-cover">
            <?php else: ?>
                <span class="avatar" style="width:1.75rem;height:1.75rem;font-size:.7rem;"><?php echo e(Str::of($course->instructor->name)->substr(0, 1)); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <p class="muted text-sm">Taught by <?php echo e($course->instructor->name); ?></p>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->description): ?>
            <div class="prose-lms mt-8"><?php echo clean($course->description); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <h2 class="display mt-10 text-2xl">What you will learn</h2>
        <div class="mt-4 space-y-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <details class="accordion panel p-4" <?php if($loop->first): ?> open <?php endif; ?>>
                    <summary class="font-semibold">
                        <span><?php echo e($section->title); ?>

                            <span class="muted ml-2 text-sm font-normal"><?php echo e($section->lessons->count()); ?> lessons</span>
                        </span>
                        <svg class="chev h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
                    </summary>
                    <div class="acc-body">
                        <div class="acc-inner">
                            <ul class="mt-3 space-y-1 text-sm">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between gap-3">
                                        <span><?php echo e($l->title); ?></span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($l->is_preview): ?><span class="pill">Preview</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <aside class="reveal lg:sticky lg:top-6 lg:self-start" x-data="{ stuck: false }"
           x-init="const io = new IntersectionObserver(([e]) => stuck = !e.isIntersecting, { threshold: 1 }); io.observe($el)">
        <div class="enrol-card panel overflow-hidden" :class="{ stuck }">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($course->thumbnail): ?>
                <img src="<?php echo e(Storage::url($course->thumbnail)); ?>" alt="" class="aspect-video w-full object-cover">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="p-5">
                <p class="display text-3xl"><?php echo e($course->isFree() ? 'Free' : $course->currency.' '.number_format($course->price_cents / 100, 2)); ?></p>
                <p class="muted mt-1 text-sm"><?php echo e($course->access_days ? $course->access_days.' days of access' : 'Lifetime access'); ?></p>

                <div class="mt-5">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($enrollment && $enrollment->isActive()): ?>
                        <a href="<?php echo e(route('learn.show', $course)); ?>" class="btn w-full">Continue learning</a>
                    <?php elseif($enrollment): ?>
                        <p class="text-sm font-medium">Your access has expired.</p>
                    <?php elseif(auth()->check()): ?>
                        <form method="POST" action="<?php echo e(route('courses.enroll', $course)); ?>"><?php echo csrf_field(); ?>
                            <button class="btn w-full"><?php echo e($course->isFree() ? 'Start course' : 'Buy course'); ?></button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn w-full">Create account to start</a>
                        <p class="muted mt-3 text-center text-sm">Already registered? <a class="underline" href="<?php echo e(route('login')); ?>">Log in</a></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </aside>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9)): ?>
<?php $attributes = $__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9; ?>
<?php unset($__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9)): ?>
<?php $component = $__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9; ?>
<?php unset($__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/catalog/show.blade.php ENDPATH**/ ?>