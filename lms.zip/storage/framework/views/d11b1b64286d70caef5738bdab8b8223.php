
<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="mx-auto max-w-xl px-4 py-10">
    <a href="<?php echo e(url()->previous() !== url()->current() ? url()->previous() : route('home')); ?>" class="muted text-sm">&larr; Back</a>

    <div class="panel mt-4 p-8 text-center">
        <span class="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[var(--mint)] text-[var(--teal-dark)]">
            <?php if (isset($component)) { $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-icon','data' => ['name' => 'academic-cap','class' => 'h-7 w-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'academic-cap','class' => 'h-7 w-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $attributes = $__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__attributesOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6)): ?>
<?php $component = $__componentOriginal0ead66fbb27509ca335b3c61efeba1a6; ?>
<?php unset($__componentOriginal0ead66fbb27509ca335b3c61efeba1a6); ?>
<?php endif; ?>
        </span>

        <h1 class="display mt-4 text-2xl">Certificate verified</h1>
        <p class="muted mt-1 text-sm">This certificate is valid and was issued by us.</p>

        <div class="mt-6 divide-y divide-[var(--line)] text-left">
            <div class="flex items-center justify-between py-3">
                <span class="muted text-sm">Awarded to</span>
                <span class="font-medium"><?php echo e($certificate->enrollment->user->name); ?></span>
            </div>
            <div class="flex items-center justify-between py-3">
                <span class="muted text-sm">Course</span>
                <span class="font-medium"><?php echo e($certificate->enrollment->course->title); ?></span>
            </div>
            <div class="flex items-center justify-between py-3">
                <span class="muted text-sm">Issued</span>
                <span class="font-medium"><?php echo e($certificate->issued_at->format('j F Y')); ?></span>
            </div>
            <div class="flex items-center justify-between py-3">
                <span class="muted text-sm">Certificate code</span>
                <span class="font-mono text-sm"><?php echo e($certificate->code); ?></span>
            </div>
        </div>

        <a href="<?php echo e(route('certificates.download', $certificate->code)); ?>" class="btn mt-6">Download PDF</a>
        <p class="muted mt-2 text-xs">Only the certificate holder or an administrator can download the PDF.</p>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/certificates/verify.blade.php ENDPATH**/ ?>