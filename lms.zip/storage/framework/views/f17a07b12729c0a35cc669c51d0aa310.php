<?php if (isset($component)) { $__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-layout','data' => ['title' => 'Certificates']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Certificates']); ?>
<div class="mx-auto max-w-4xl px-4 py-8">
    <h1 class="display text-3xl">Your certificates</h1>
    <p class="muted mt-1">Every certificate has a public verification link you can share.</p>

    <div class="mt-6 space-y-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="panel flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
                <span class="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-[var(--mint)] text-[var(--teal-dark)]">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-academic-cap'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <div class="min-w-0 flex-1">
                    <h2 class="display text-lg"><?php echo e($e->course->title); ?></h2>
                    <p class="muted text-sm">Issued <?php echo e($e->certificate->issued_at->format('j F Y')); ?> &middot; Code <?php echo e(Str::substr($e->certificate->code, 0, 8)); ?></p>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="<?php echo e(route('certificates.download', $e->certificate->code)); ?>" class="btn !py-2 text-sm">Download PDF</a>
                    <a href="<?php echo e(route('certificates.show', $e->certificate->code)); ?>" class="btn btn-quiet !py-2 text-sm">Verification page</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="panel p-8 text-center">
                <p class="font-medium">No certificates yet.</p>
                <p class="muted mt-1 text-sm">Finish every lesson in a course and your certificate appears here.</p>
                <a href="<?php echo e(route('my.courses')); ?>" class="btn mt-4">Go to my courses</a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3)): ?>
<?php $attributes = $__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3; ?>
<?php unset($__attributesOriginal0c9d91dcce9c4f04354062c6c06b27f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3)): ?>
<?php $component = $__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3; ?>
<?php unset($__componentOriginal0c9d91dcce9c4f04354062c6c06b27f3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/student/certificates.blade.php ENDPATH**/ ?>