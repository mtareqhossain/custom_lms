<?php if (isset($component)) { $__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lms-layout','data' => ['title' => $lesson->title.' | '.$course->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lms-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lesson->title.' | '.$course->title)]); ?>
<div class="mx-auto grid max-w-7xl gap-8 px-4 py-6 lg:grid-cols-[22rem_1fr]">

    <aside x-data="{ open: false, p: <?php echo e($previousProgress / 100); ?> }"
           x-init="$nextTick(() => p = <?php echo e($enrollment->progress_percent / 100); ?>)">
        <button type="button" class="btn btn-quiet w-full justify-between lg:hidden" @click="open = !open" :aria-expanded="open">
            <span>Curriculum</span><span><?php echo e($enrollment->progress_percent); ?>% complete</span>
        </button>
        <div :class="open ? 'block' : 'hidden'" class="mt-3 lg:!block lg:mt-0">
            <p class="display hidden text-lg lg:block"><?php echo e($course->title); ?></p>
            <p class="muted mb-2 hidden text-sm lg:block"><?php echo e($enrollment->progress_percent); ?>% complete</p>
            <nav class="track" :style="`--p:${p}`" aria-label="Course curriculum">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="track-section"><?php echo e($section->title); ?></p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($done = in_array($l->id, $completed)); ?>
                        <?php ($current = $l->id === $lesson->id); ?>
                        <a href="<?php echo e(route('learn.show', [$course, $l])); ?>" class="track-item <?php echo e($current ? 'is-current' : ''); ?>"
                           <?php if($current): ?> aria-current="page" <?php endif; ?>>
                            <span class="dot <?php echo e($done ? 'done' : ''); ?> <?php echo e($current ? 'current' : ''); ?>">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($done): ?>
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 6.5l2.5 2.5L10 3.5"/></svg>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </span>
                            <?php echo e($l->title); ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($l->duration_seconds): ?><span class="muted ml-1 text-xs"><?php echo e(ceil($l->duration_seconds / 60)); ?> min</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </nav>
        </div>
    </aside>

    <section class="lesson-fade" wire:key="<?php echo e($lesson->id); ?>">
        <h1 class="display text-2xl sm:text-3xl"><?php echo e($lesson->title); ?></h1>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($video): ?>
            <div class="video-frame mt-5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($video['type'] === 'iframe'): ?>
                    <iframe src="<?php echo e($video['url']); ?>" class="aspect-video w-full" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen title="<?php echo e($lesson->title); ?>"></iframe>
                <?php else: ?>
                    <video src="<?php echo e($video['url']); ?>" class="aspect-video w-full" controls controlsList="nodownload"></video>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lesson->content): ?>
            <div class="prose-lms mt-6"><?php echo clean($lesson->content); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lesson->attachment): ?>
            <a href="<?php echo e(Storage::url($lesson->attachment)); ?>" class="btn btn-quiet mt-6" download>Download lesson file</a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lesson->quizzes->isNotEmpty()): ?>
            <div class="mt-6 space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $lesson->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalfe78416fef05351c087ab03826eed8ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe78416fef05351c087ab03826eed8ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quiz-card','data' => ['quiz' => $quiz,'user' => auth()->user()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quiz-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['quiz' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quiz),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(auth()->user())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe78416fef05351c087ab03826eed8ba)): ?>
<?php $attributes = $__attributesOriginalfe78416fef05351c087ab03826eed8ba; ?>
<?php unset($__attributesOriginalfe78416fef05351c087ab03826eed8ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe78416fef05351c087ab03826eed8ba)): ?>
<?php $component = $__componentOriginalfe78416fef05351c087ab03826eed8ba; ?>
<?php unset($__componentOriginalfe78416fef05351c087ab03826eed8ba); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="mt-8 flex flex-wrap items-center gap-3 border-t border-[var(--line)] pt-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prev): ?><a href="<?php echo e(route('learn.show', [$course, $prev])); ?>" class="btn btn-quiet">Previous</a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="flex-1"></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isDone): ?>
                <span class="pill check-pop inline-flex items-center gap-1">
                    <svg width="14" height="14" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 6.5l2.5 2.5L10 3.5"/></svg>
                    Completed
                </span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($next): ?>
                    <a href="<?php echo e(route('learn.show', [$course, $next])); ?>" class="btn">Next lesson</a>
                <?php elseif($course->finalQuizzes->isNotEmpty()): ?>
                    <div class="w-full mt-4 space-y-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $course->finalQuizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginalfe78416fef05351c087ab03826eed8ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe78416fef05351c087ab03826eed8ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quiz-card','data' => ['quiz' => $quiz,'user' => auth()->user()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quiz-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['quiz' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quiz),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(auth()->user())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe78416fef05351c087ab03826eed8ba)): ?>
<?php $attributes = $__attributesOriginalfe78416fef05351c087ab03826eed8ba; ?>
<?php unset($__attributesOriginalfe78416fef05351c087ab03826eed8ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe78416fef05351c087ab03826eed8ba)): ?>
<?php $component = $__componentOriginalfe78416fef05351c087ab03826eed8ba; ?>
<?php unset($__componentOriginalfe78416fef05351c087ab03826eed8ba); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <form method="POST" action="<?php echo e(route('learn.complete', [$course, $lesson])); ?>"><?php echo csrf_field(); ?>
                    <button class="btn"><?php echo e($next ? 'Complete and continue' : 'Complete course'); ?></button>
                </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        </section>
</div>

<?php if (isset($component)) { $__componentOriginal1e0e922b71079bfd5b9f9cc0b6760397 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e0e922b71079bfd5b9f9cc0b6760397 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.course-chatbot','data' => ['course' => $course]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('course-chatbot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['course' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e0e922b71079bfd5b9f9cc0b6760397)): ?>
<?php $attributes = $__attributesOriginal1e0e922b71079bfd5b9f9cc0b6760397; ?>
<?php unset($__attributesOriginal1e0e922b71079bfd5b9f9cc0b6760397); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e0e922b71079bfd5b9f9cc0b6760397)): ?>
<?php $component = $__componentOriginal1e0e922b71079bfd5b9f9cc0b6760397; ?>
<?php unset($__componentOriginal1e0e922b71079bfd5b9f9cc0b6760397); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9)): ?>
<?php $attributes = $__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9; ?>
<?php unset($__attributesOriginal2e208277acdbd9eb96ab5dcd963b67f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9)): ?>
<?php $component = $__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9; ?>
<?php unset($__componentOriginal2e208277acdbd9eb96ab5dcd963b67f9); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lms\resources\views/learn/show.blade.php ENDPATH**/ ?>